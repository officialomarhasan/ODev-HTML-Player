package com.odev.htmlplayer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.app.DownloadManager;

public class MainActivity extends Activity {
    private static final int PICK_HTML = 4101;
    private static final int PICK_UPLOAD = 4102;
    private WebView web;
    private LinearLayout root, toolbar;
    private ProgressBar progress;
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> uploadCallback;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private int bg = Color.rgb(15,18,27), panel = Color.rgb(29,35,49);
    private int fg = Color.rgb(240,243,250), accent = Color.rgb(139,120,255);
    private boolean dark = true;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("odev_player", MODE_PRIVATE);
        dark = prefs.getBoolean("dark", true);
        buildUI();
        setupWebView();
        handleLaunchIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleLaunchIntent(intent);
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }

    private TextView button(String label) {
        TextView t = new TextView(this);
        t.setText(label); t.setTextColor(fg); t.setTextSize(13);
        t.setGravity(Gravity.CENTER); t.setPadding(9, 11, 9, 11);
        t.setBackground(shape(panel, 16));
        t.setClickable(true); t.setFocusable(true);
        return t;
    }

    private void buildUI() {
        bg = dark ? Color.rgb(15,18,27) : Color.rgb(245,247,250);
        panel = dark ? Color.rgb(29,35,49) : Color.rgb(226,232,240);
        fg = dark ? Color.rgb(240,243,250) : Color.rgb(25,32,45);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);

        toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(10, 8, 10, 8);
        toolbar.setBackgroundColor(bg);

        TextView brand = new TextView(this);
        brand.setText("ODev"); brand.setTextColor(accent);
        brand.setTextSize(20); brand.setTypeface(null, 1);
        toolbar.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));

        TextView open = button("Open HTML");
        TextView settings = button("Settings");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, 42);
        bp.setMargins(4,0,4,0);
        toolbar.addView(open, bp);
        toolbar.addView(settings, bp);
        open.setOnClickListener(v -> pickHtml());
        settings.setOnClickListener(v -> showSettings());

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(accent));

        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER);
        bottom.setPadding(8, 7, 8, 8);
        bottom.setBackgroundColor(bg);
        TextView back = button("Back");
        TextView home = button("Home");
        TextView reload = button("Reload");
        TextView full = button("Full screen");
        TextView[] buttons = {back, home, reload, full};
        for (TextView b : buttons) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, 44, 1);
            p.setMargins(3,0,3,0); bottom.addView(b,p);
        }
        back.setOnClickListener(v -> { if (web.canGoBack()) web.goBack(); });
        home.setOnClickListener(v -> loadHome());
        reload.setOnClickListener(v -> web.reload());
        full.setOnClickListener(v -> enterImmersive());

        root.addView(toolbar);
        root.addView(progress, new LinearLayout.LayoutParams(-1, 3));
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(bottom);
        setContentView(root);
    }

    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setDefaultTextEncodingName("UTF-8");
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setGeolocationEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) {
                progress.setProgress(value);
                progress.setVisibility(value >= 100 ? View.GONE : View.VISIBLE);
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                try {
                    Intent i = params.createIntent();
                    startActivityForResult(i, PICK_UPLOAD);
                    return true;
                } catch (Exception e) {
                    uploadCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "ফাইল নির্বাচন করা যায়নি", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view; customViewCallback = callback;
                root.setVisibility(View.GONE);
                addContentView(view, new ViewGroup.LayoutParams(-1,-1));
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                enterImmersive();
            }
            @Override public void onHideCustomView() {
                if (customView == null) return;
                ((ViewGroup)customView.getParent()).removeView(customView);
                customView = null;
                root.setVisibility(View.VISIBLE);
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                if (customViewCallback != null) customViewCallback.onCustomViewHidden();
                customViewCallback = null;
                showSystemUI();
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)
                    || "file".equalsIgnoreCase(scheme) || "content".equalsIgnoreCase(scheme)
                    || "about".equalsIgnoreCase(scheme) || "data".equalsIgnoreCase(scheme)) {
                    if (request.isForMainFrame() && ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme))) {
                        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); }
                        catch (Exception ignored) {}
                        return true;
                    }
                    return false;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri u = Uri.parse(url);
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                    return true;
                }
                return "file".equalsIgnoreCase(scheme) || "content".equalsIgnoreCase(scheme)
                    || "about".equalsIgnoreCase(scheme) || "data".equalsIgnoreCase(scheme) ? false : true;
            }
        });

        web.setDownloadListener((url, agent, disposition, mime, length) -> {
            try {
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setTitle(URLUtil.guessFileName(url, disposition, mime));
                r.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS,
                    URLUtil.guessFileName(url, disposition, mime));
                ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                Toast.makeText(this, "ডাউনলোড শুরু হয়েছে", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "ডাউনলোড করা যায়নি", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void handleLaunchIntent(Intent intent) {
        if (intent != null && (Intent.ACTION_VIEW.equals(intent.getAction()) || Intent.ACTION_SEND.equals(intent.getAction()))) {
            Uri uri = intent.getData();
            if (uri == null && intent.getClipData() != null && intent.getClipData().getItemCount() > 0)
                uri = intent.getClipData().getItemAt(0).getUri();
            if (uri != null) { openUri(uri, intent); return; }
        }
        String last = prefs.getString("last_uri", null);
        if (last != null) {
            try { web.loadUrl(last); return; } catch (Exception ignored) {}
        }
        loadHome();
    }

    private void openUri(Uri uri, Intent source) {
        try {
            int flags = source.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if ((flags & Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0) {
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                catch (Exception ignored) {}
            }
            prefs.edit().putString("last_uri", uri.toString()).apply();
            web.loadUrl(uri.toString());
        } catch (Exception e) {
            Toast.makeText(this, "এই HTML ফাইল খোলা যায়নি", Toast.LENGTH_LONG).show();
            loadHome();
        }
    }

    private void loadHome() {
        prefs.edit().remove("last_uri").apply();
        web.loadUrl("file:///android_asset/start.html");
    }

    private void pickHtml() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/html","application/xhtml+xml"});
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, PICK_HTML);
    }

    private void showSettings() {
        String[] items = {"Theme: " + (dark ? "Dark" : "Light"), "JavaScript: ON", "Clear Web Cache", "Clear Saved Website Data"};
        new AlertDialog.Builder(this).setTitle("ODev Settings").setItems(items, (d, which) -> {
            if (which == 0) {
                dark = !dark; prefs.edit().putBoolean("dark", dark).apply();
                Toast.makeText(this, "Theme পরিবর্তন হয়েছে। অ্যাপ পুনরায় খুললে সম্পূর্ণ প্রয়োগ হবে।", Toast.LENGTH_LONG).show();
                recreate();
            } else if (which == 1) {
                Toast.makeText(this, "HTML চালানোর জন্য JavaScript চালু রাখা হয়েছে।", Toast.LENGTH_SHORT).show();
            } else if (which == 2) {
                web.clearCache(true); Toast.makeText(this, "Cache পরিষ্কার হয়েছে", Toast.LENGTH_SHORT).show();
            } else if (which == 3) {
                new AlertDialog.Builder(this).setMessage("Cookies, LocalStorage ও WebView database মুছে যাবে।")
                    .setNegativeButton("Cancel", null).setPositiveButton("Clear", (x,y) -> {
                        CookieManager.getInstance().removeAllCookies(null);
                        CookieManager.getInstance().flush();
                        web.clearFormData(); web.clearHistory();
                        Toast.makeText(this, "Website data মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show();
                    }).show();
            }
        }).setNegativeButton("Close", null).show();
    }

    private void enterImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }
    private void showSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_HTML) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) openUri(data.getData(), data);
        } else if (requestCode == PICK_UPLOAD && uploadCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            uploadCallback.onReceiveValue(result);
            uploadCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (customView != null) { web.getWebChromeClient().onHideCustomView(); return; }
        if (web != null && web.canGoBack()) web.goBack();
        else loadHome();
    }

    @Override protected void onDestroy() {
        if (uploadCallback != null) { uploadCallback.onReceiveValue(null); uploadCallback = null; }
        if (web != null) { web.stopLoading(); web.setWebChromeClient(null); web.destroy(); }
        super.onDestroy();
    }
}
