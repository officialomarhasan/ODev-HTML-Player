ODev HTML Player v2 (Offline-first)

এই সংস্করণে:
- URL/search bar সরানো হয়েছে; এটি সাধারণ ব্রাউজার নয়।
- Android ACTION_VIEW intent filter: HTML ফাইলের Open with সমর্থন।
- অ্যাপের Open HTML picker।
- JavaScript, DOM Storage, Cookies, Database, cache ও media playback সেটিংস।
- HTML file upload chooser, download handling, fullscreen video।
- Home, Back, Reload, Theme ও Settings।
- HTML-এর মধ্যে থাকা online resource নেটওয়ার্ক থাকলে লোড হতে পারে।

Build:
- JDK 17
- Android Gradle Plugin 8.6.1 / Gradle 8.7
- compileSdk 35, minSdk 23
- Android Studio/AndroidIDE দিয়ে project sync করে assembleDebug করুন.

গুরুত্বপূর্ণ সীমা:
- Android WebView-এর ইঞ্জিন/ফিচার ডিভাইসের Android System WebView বা Chrome WebView provider-এর সংস্করণের ওপর নির্ভরশীল।
- WebView storage cookies/DOM storage চালু করা হয়েছে; তবে সব HTML ফাইলের origin-এ LocalStorage/IndexedDB একইভাবে persist হবে এমন নিশ্চয়তা নেই, বিশেষ করে file:// ও content:// origin-এর ক্ষেত্রে।
- নির্বাচিত HTML ফাইলের পাশের আলাদা asset ফাইলের relative path সমর্থন ফাইল provider ও URI permission-এর ওপর নির্ভরশীল।
- Open with intent filter MIME type সঠিকভাবে দেওয়া File Manager-এর ওপরও নির্ভর করে; সব File Manager একই MIME পাঠায় না।
- Main frame HTTP/HTTPS লিংক আলাদা ব্রাউজারে খোলে; HTML-এর image/script/css/fetch/iframe resource WebView-এ লোড হতে পারে।
