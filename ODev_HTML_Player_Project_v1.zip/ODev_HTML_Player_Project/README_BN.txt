ODev HTML Player — প্রথম সংস্করণ

প্রজেক্টে যা আছে:
- Android WebView
- JavaScript এবং DOM Storage
- Online URL load
- ফোন/SD Card থেকে HTML document picker দিয়ে খোলা
- HTML file upload chooser
- Download Manager integration
- Back/Forward/Home/Reload
- Dark interface
- Minimum Android 6.0 (API 23)

APK তৈরি:
1) AndroidIDE-তে ZIP extract করে project folder খুলুন।
2) Gradle sync সম্পন্ন করুন।
3) Build > Assemble Debug (অথবা Build APK) নির্বাচন করুন।
4) APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-এ তৈরি হবে।

প্রয়োজন:
- AndroidIDE-তে JDK 17 এবং Android SDK Platform 35 / Build Tools উপলব্ধ থাকতে হবে।
- প্রথম Gradle build-এ ইন্টারনেট লাগতে পারে।
- Android 6-এ চলার জন্য minSdk 23; কিন্তু Android System WebView পুরোনো হলে আধুনিক JavaScript/API সীমিত হতে পারে।

সীমাবদ্ধতা:
- এই starter build-এ native Picture-in-Picture, subtitle manager, custom home-screen shortcut, multi-tab manager, app library/backup এখনো যোগ করা হয়নি।
- SD card access Android document picker-এর মাধ্যমে; Android-এর নিরাপত্তা নিয়ম অনুযায়ী অনুমতি দিতে হবে।
- শুধু বিশ্বাসযোগ্য HTML ফাইল খুলুন। JavaScript সক্রিয় থাকায় অজানা ফাইলের ওপর সতর্ক থাকুন।
