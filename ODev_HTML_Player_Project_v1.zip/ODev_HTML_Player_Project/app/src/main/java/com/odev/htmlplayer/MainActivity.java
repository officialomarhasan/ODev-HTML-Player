package com.odev.htmlplayer;

import android.app.DownloadManager;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Gravity;
import android.webkit.*;
import android.widget.*;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    private static final int PICK_HTML = 4101;
    private WebView web;
    private EditText address;
    private ProgressBar progress;
    private LinearLayout root;
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> uploadCallback;

    private int bg = Color.rgb(15, 18, 27);
    private int panel = Color.rgb(27, 32, 45);
    private int fg = Color.rgb(240, 243, 250);
    private int accent = Color.rgb(116, 92, 255);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("odev_player", MODE_PRIVATE);
        buildUI();
        setupWebView();
        String last = prefs.getString("last_url", "file:///android_asset/start.html");
        web.loadUrl(last);
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView button(String text) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(fg);
        b.setTextSize(14);
        b.setGravity(Gravity.CENTER);
        b.setPadding(13, 11, 13, 11);
        b.setBackground(shape(panel, 18));
        return b;
    }

    private void buildUI() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(10, 10, 10, 6);
        top.setBackgroundColor(bg);

        TextView brand = new TextView(this);
        brand.setText("ODev");
        brand.setTextColor(accent);
        brand.setTextSize(20);
        brand.setTypeface(null, 1);
        top.addView(brand, new LinearLayout.LayoutParams(-2, -2));

        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(fg);
        address.setHintTextColor(Color.GRAY);
        address.setHint("Enter URL or search");
        address.setTextSize(14);
        address.setPadding(12, 0, 12, 0);
        address.setBackground(shape(panel, 16));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, 46, 1);
        ap.setMargins(10, 0, 8, 0);
        top.addView(address, ap);

        TextView go = button("GO");
        top.addView(go, new LinearLayout.LayoutParams(-2, 46));
        go.setOnClickListener(v -> loadAddress());

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(accent));
        progress.setVisibility(View.GONE);

        root.addView(top);
        root.addView(progress, new LinearLayout.LayoutParams(-1, 3));

        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER);
        bottom.setPadding(7, 7, 7, 9);
        bottom.setBackgroundColor(bg);

        TextView back = button("‹");
        TextView forward = button("›");
        TextView home = button("Home");
        TextView open = button("Open HTML");
        TextView reload = button("↻");
        TextView[] items = {back, forward, home, open, reload};
        for (TextView t : items) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, 46, 1);
            p.setMargins(3, 0, 3, 0);
            bottom.addView(t, p);
        }
        back.setOnClickListener(v -> { if (web.canGoBack()) web.goBack(); });
        forward.setOnClickListener(v -> { if (web.canGoForward()) web.goForward(); });
        home.setOnClickListener(v -> web.loadUrl("file:///android_asset/start.html"));
        open.setOnClickListener(v -> pickHtml());
        reload.setOnClickListener(v -> web.reload());
        root.addView(bottom);
        setContentView(root);
    }

    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadsImagesAutomatically(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.setBackgroundColor(Color.WHITE);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
                if (p >= 100) address.setText(view.getUrl());
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                Intent i = params.createIntent();
                try { startActivityForResult(i, 4102); }
                catch (Exception e) { uploadCallback = null; return false; }
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, Bitmap icon) {
                address.setText(url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                prefs.edit().putString("last_url", url).apply();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("http://") || url.startsWith("https://") ||
                    url.startsWith("file://") || url.startsWith("content://")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (Exception ignored) {}
                return true;
            }
        });
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType));
                request.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS,
                    URLUtil.guessFileName(url, contentDisposition, mimeType));
                android.app.DownloadManager dm = (android.app.DownloadManager)getSystemService(DOWNLOAD_SERVICE);
                dm.enqueue(request);
                Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Download unavailable for this link", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void loadAddress() {
        String u = address.getText().toString().trim();
        if (u.length() == 0) return;
        if (!u.contains("://") && u.contains(".") && !u.contains(" ")) u = "https://" + u;
        else if (!u.startsWith("http://") && !u.startsWith("https://") &&
                 !u.startsWith("file://") && !u.startsWith("content://")) {
            u = "https://www.google.com/search?q=" + Uri.encode(u);
        }
        web.loadUrl(u);
    }

    private void pickHtml() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/html");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, PICK_HTML);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_HTML && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) {}
            web.loadUrl(uri.toString());
        } else if (requestCode == 4102 && uploadCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            uploadCallback.onReceiveValue(results);
            uploadCallback = null;
        } else if (requestCode == 4102 && uploadCallback != null) {
            uploadCallback.onReceiveValue(null);
            uploadCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (web != null) { web.stopLoading(); web.destroy(); }
        super.onDestroy();
    }
}
